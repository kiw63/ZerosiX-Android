# ZerosiX Android

Developer: @Marvel_sh

ZerosiX is a native Android security/terminal interface inspired by the visual language of eDEX-UI, with a real Android PTY terminal, real system telemetry, real Tor integration, and an optional real Linux userland through proot + an imported Linux rootfs.

## What is real

- Terminal: Termux terminal-view/terminal-emulator `TerminalSession`, which uses a PTY subprocess.
- CPU/RAM/storage/battery: Android/Linux system data, not random telemetry.
- Network: Android ConnectivityManager + TrafficStats.
- Tor: Guardian Project `tor-android`, real Tor daemon/service.
- Linux: real rootless Linux userland when a real `proot` executable and real rootfs have been imported.
- Sound: original synthesized WAV cues included in the app.
- Startup animation: native Android animation sequence, with boot lines appearing one by one.

## Linux setup

The APK intentionally does not pretend that a Linux distro exists when it has not been installed. Open **LINUX** and import:

1. A trusted `proot` executable for the device ABI.
2. An already-extracted Linux rootfs folder containing `/bin/sh`.

After both are present, ZerosiX launches the rootfs through proot and the terminal is a real Linux userland. PRoot provides a rootless, chroot-like Linux environment without requiring Android root; it shares the Android kernel.

## Tor

The app uses Guardian Project's native Tor Android library. The Tor daemon is real; the UI status is driven by Tor service status broadcasts. Tor is a privacy-routing feature and does not make every application or command automatically anonymous.

## Build

Open this project in Android Studio and sync Gradle. Or push it to GitHub: the included `.github/workflows/build-apk.yml` builds `app-debug.apk` automatically and uploads it as a workflow artifact.

## Important Android limitation

There is no single Android permission that grants unrestricted access to the whole device. ZerosiX requests only permissions/APIs that Android actually exposes. Rooted devices may provide additional capabilities, but the APK does not claim root access unless the user/device actually provides it.

## Security scope

The terminal is intentionally general-purpose. Security tooling should be used only on systems, accounts, and networks you own or are explicitly authorized to test.

## Main references

- Termux terminal libraries: https://github.com/termux/termux-app
- Guardian Project Tor Android: https://github.com/guardianproject/tor-android
- PRoot-Distro: https://github.com/termux/proot-distro
